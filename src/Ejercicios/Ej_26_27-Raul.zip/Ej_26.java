package Ejercicios;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Ej_26 {

	public static void main(String[] args) {
		String ruta = "empleados.bin";

		Empleado empInicial = new Empleado("12345678A", "Paco", 3000);

		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ruta))) {
			oos.writeObject(empInicial);
			System.out.println("Empleado guardado correctamente en " + ruta);
		} catch (IOException e) {
			System.out.println("Error al escribir el empleado: " + e.getMessage());
		}

		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ruta))) {
			Empleado empLeido = (Empleado) ois.readObject();
			System.out.println("Empleado leído desde el fichero:");
			System.out.println(empLeido);
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Error al leer el empleado: " + e.getMessage());
		}
	}

}
